//
//  ErrorManager.swift
//  WeatherV2
//
//  Created by Markiyan Prysiazhniuk on 2/20/19.
//  Copyright © 2019 Markiyan Prysiazhniuk. All rights reserved.
//

import Foundation

public let SWINetworkingErrorDomain = "https.github.com.Pryssss"
public let MissingHTTPResponseError = 100
public let UnexpectedResponseError = 200

